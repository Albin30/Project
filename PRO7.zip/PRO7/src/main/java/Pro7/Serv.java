package Pro7;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Serv
 */
public class Serv extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Serv() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		Connection cn;
		Statement smt;
		ResultSet rs;
		
		try
		{
			Class.forName("oracle.jdbc.driver.oracleDriver");
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			rs=smt.executeQuery("Select*from mystu");
			out.println("<center>");
			out.println("RESULTS");
			out.println("<hr/>");
			out.println("<table border=1>");
			out.println("<tr><td>"+"Name"+"</td"+"<td>"+"Rollno "+"<td>"+"Physics"+"<td>"+"Maths"+"<td>"+"Malayalam"+"<td>"+"Chemistry"+"<td>"+"English"+"</td></tr>");
		while(rs.next())	
		    {
			 out.println("<tr><th>"+rs.getString(1)+"<th>"+"<th>"+rs.getString(2)+"</th>"+"<th>"+rs.getString(3)+"</th>"+"<th>"+rs.getString(4)+"</th>"+"<th>"+rs.getString(5)+"</th>"+"<th>");
			 
			 out.println("</center>");
       			}  
		
		   cn.commit();
		   smt.close();
		   cn.close();
		}
		catch(Exception e)
		{
			
		}
		out.println("<marquee style=color:Yellow>Best Of Luck</marquee");
		}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

}
