package Pro7;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class INSERT
 */
public class INSERT extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public INSERT() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

     PrintWriter out=response.getWriter();
     
     response.setContentType("text/html");
     String name=request.getParameter("nm");
     String roll=request.getParameter("roll");
     
     
     int m1=Integer.parseInt(request.getParameter("m1"));
     int m2=Integer.parseInt(request.getParameter("m2"));
     int m3=Integer.parseInt(request.getParameter("m3"));
     int m4=Integer.parseInt(request.getParameter("m4"));
     int m5=Integer.parseInt(request.getParameter("m5"));
     
     double percent;
     percent=(m1+m2+m3+m4+m5)/5;
     
     String grade;
     if(percent>80.00 && percent<100.00)
     {
    	 grade="A";
     }
     else if(percent>60.00 && percent<80.00)
     {
    	 grade="B";
     }
     
     else if(percent>400.00 && percent<60.00)
     {
    	 grade="C";
     }
     else 
     {
    	 grade="F";
     }
     
     
     String a="DATA SAVED SUCCESFULLY";
     request.setAttribute("a", a);
     
     Connection cn;
     Statement smt;
     try
     {
    	 Class.forName("oracle.jdbc.driver.oracleDriver");
		cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
		
		smt=cn.createStatement();
		smt.executeUpdate("insert into mystu values('"+name+"','"+roll+"',"+m1+","+m2+","+m3+","+m4+","+m5+","+percent+","+grade+"')");
		out.println(a);
		smt.close();
		cn.close();
     }
     catch(Exception e)
     {
    	 
     }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
